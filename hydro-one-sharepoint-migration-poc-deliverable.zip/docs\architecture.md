# Hydro One SharePoint to Azure Migration - Architecture Document

## Executive Summary

This document outlines the technical architecture for migrating approximately **25 TB** of data from SharePoint Online to Azure Data Lake Storage Gen2 (ADLS Gen2) for Hydro One. The solution leverages Azure Data Factory (ADF) as the orchestration engine with a metadata-driven approach for scalability and maintainability. File access is handled entirely through Microsoft Graph API, with cross-tenant authentication from the MCAPS tenant to the Hydro One SharePoint tenant.

## Solution Architecture Diagram

```mermaid
graph TB
    subgraph "Source - SharePoint Online (Hydro One Tenant)"
        SPO[SharePoint Online Tenant]
        SPO --> |Graph API| SITES[Site Collections]
        SITES --> LIBS[Document Libraries / Drives]
        LIBS --> FILES[Files & Folders]
    end

    subgraph "Azure Data Factory (MCAPS Tenant)"
        ADF[Azure Data Factory]
        ADF --> MASTER[PL_Master_Orchestrator]
        MASTER --> |ForEach| CHILD[PL_Migrate_Single_Library]
        CHILD --> |ExecutePipeline| COPYBATCH[PL_Copy_File_Batch]
        CHILD --> SUBFOLDER[PL_Process_Subfolder]
        SUBFOLDER --> |ExecutePipeline| COPYBATCH
        ADF --> VALIDATION[PL_Post_Migration_Validation]
        ADF --> INCREMENTAL[PL_Incremental_Sync]
        INCREMENTAL --> |ExecutePipeline| COPYBATCH

        subgraph "Linked Services"
            LS_GRAPH[LS_HTTP_Graph_API<br/>Base URL: https://graph.microsoft.com<br/>Auth: Anonymous]
            LS_ADLS[LS_ADLS_Gen2]
            LS_SQL[LS_AzureSqlDatabase]
            LS_KV[LS_AzureKeyVault]
        end

        subgraph "Datasets"
            DS_GRAPH[DS_Graph_Content_Download<br/>File download via Graph /content]
            DS_ADLS_SINK[DS_ADLS_Binary_Sink<br/>Write to ADLS Gen2]
            DS_SQL_CTRL[DS_SQL_MigrationControl<br/>Control table access]
        end
    end

    subgraph "Azure Key Vault"
        KV[Key Vault]
        KV --> SECRET[Client Secret]
        KV --> TENANT[SharePoint Tenant ID]
    end

    subgraph "Control Database - Azure SQL"
        SQL[(Azure SQL DB)]
        SQL --> CONTROL[MigrationControl Table]
        SQL --> AUDIT[MigrationAuditLog Table]
        SQL --> WATERMARK[IncrementalWatermark Table]
    end

    subgraph "Destination - Azure Storage"
        ADLS[ADLS Gen2]
        ADLS --> CONTAINER[sharepoint-migration]
        CONTAINER --> SITEFOLDERS[Site Folders]
        SITEFOLDERS --> LIBFOLDERS[Library Folders]
        LIBFOLDERS --> DESTFILES[Migrated Files]

        ADLS --> META[migration-metadata]
        META --> PARQUET[Parquet Files]
    end

    subgraph "Authentication (Cross-Tenant)"
        AAD_SP[Azure AD - SharePoint Tenant]
        AAD_SP --> SP[Service Principal<br/>App Registration]
        SP --> |OAuth2 client_credentials| GRAPH_API[Microsoft Graph API]
        GRAPH_API --> SPO
        AAD_MCAPS[Azure AD - MCAPS Tenant]
        AAD_MCAPS --> MI[Managed Identity<br/>ADF System-Assigned]
        MI --> ADLS
        MI --> SQL
        MI --> KV
    end

    SPO --> |Graph API /v1.0| ADF
    ADF --> |Managed Identity| ADLS
    ADF --> |Managed Identity| SQL
    ADF --> |Managed Identity| KV
    LS_KV --> KV
    LS_GRAPH --> |Bearer Token| GRAPH_API
```

## Component Overview

### Source: SharePoint Online

| Component | Description |
|-----------|-------------|
| SharePoint Tenant | `https://hydroone.sharepoint.com` (separate tenant from ADF) |
| Site Collections | Multiple sites containing document libraries |
| Document Libraries | ~25 TB of files across various formats |
| API | Microsoft Graph API v1.0 (`https://graph.microsoft.com/v1.0/`) |

### Orchestration: Azure Data Factory

| Pipeline | Purpose |
|----------|---------|
| `PL_Master_Migration_Orchestrator` | Master pipeline reading from control table, iterating through libraries |
| `PL_Migrate_Single_Library` | Migrates all files from a single library using Graph API delta query with paginated Until loop; calls `PL_Copy_File_Batch` via ExecutePipeline |
| `PL_Copy_File_Batch` | Lightweight child pipeline containing ForEach loop for file copy (via Graph `/content`) + audit logging (Log_Success, Log_Failure). Called by all 3 paginated pipelines |
| `PL_Process_Subfolder` | Processes subfolder children with paginated Until loop; calls `PL_Copy_File_Batch` via ExecutePipeline |
| `PL_Incremental_Sync` | Delta sync with deltaLink persistence and paginated Until loop; calls `PL_Copy_File_Batch` via ExecutePipeline |
| `PL_Post_Migration_Validation` | Post-migration file count/size validation comparing source vs destination |

> **Note:** `PL_Migrate_Single_Library` uses Graph API delta query (`/root/delta`) which returns ALL files at ALL folder depths in a flat list, eliminating the need for recursive subfolder traversal. `PL_Process_Subfolder` is retained as a standalone utility.

> **Note:** `PL_Copy_File_Batch` was introduced because ADF's Until activity cannot contain container activities (ForEach, IfCondition, Switch). Only ExecutePipeline is allowed as a container child inside Until. The ForEach file copy logic was therefore extracted into this dedicated child pipeline.

### Linked Services

| Linked Service | Type | Configuration |
|----------------|------|---------------|
| `LS_HTTP_Graph_API` | HTTP | Base URL: `https://graph.microsoft.com`, Authentication: Anonymous (Bearer token passed via request headers) |
| `LS_AzureSqlDatabase` | Azure SQL Database | Managed Identity authentication |
| `LS_AzureKeyVault` | Azure Key Vault | Managed Identity authentication |
| `LS_ADLS_Gen2` | Azure Data Lake Storage Gen2 | Managed Identity authentication |

### Datasets

| Dataset | Type | Purpose |
|---------|------|---------|
| `DS_Graph_Content_Download` | HTTP / Binary | Downloads file content from Graph API `/v1.0/drives/{driveId}/items/{itemId}/content` endpoint |
| `DS_ADLS_Binary_Sink` | ADLS Gen2 / Binary | Writes binary file content to ADLS Gen2 destination path |
| `DS_SQL_MigrationControl` | Azure SQL | Reads/writes migration control and audit data |

### Storage: Azure Data Lake Storage Gen2

| Container | Purpose |
|-----------|---------|
| `sharepoint-migration` | Primary destination for migrated files |
| `migration-metadata` | Metadata, manifests, and reporting data |

**Folder Structure:**
```
sharepoint-migration/
├── SiteName1/
│   ├── Documents/
│   │   ├── Folder1/
│   │   │   └── file1.pdf
│   │   └── file2.docx
│   └── SharedDocuments/
│       └── ...
└── SiteName2/
    └── ...
```

### Control Database: Azure SQL

| Table | Purpose |
|-------|---------|
| `MigrationControl` | Tracks all libraries to migrate with status |
| `MigrationAuditLog` | Per-file audit trail |
| `IncrementalWatermark` | High watermark for delta sync |
| `BatchLog` | Batch execution tracking |

## Authentication Flow

### Cross-Tenant Architecture

ADF runs on the **MCAPS tenant**, while SharePoint Online resides on the **Hydro One tenant**. The Service Principal (App Registration) is registered in the SharePoint tenant, and its client secret is stored in Azure Key Vault (accessible to ADF via Managed Identity). The OAuth2 token is acquired against the **SharePoint tenant's AAD token endpoint**, with the scope set to `https://graph.microsoft.com/.default`.

```mermaid
sequenceDiagram
    participant ADF as Azure Data Factory<br/>(MCAPS Tenant)
    participant KV as Key Vault
    participant AAD as Azure AD<br/>(SharePoint Tenant)
    participant GRAPH as Microsoft Graph API
    participant SPO as SharePoint Online<br/>(Hydro One Tenant)
    participant ADLS as ADLS Gen2

    ADF->>KV: 1. Retrieve Client Secret & Tenant ID (Managed Identity / MSI)
    KV-->>ADF: Return Secret + SharePoint Tenant ID
    ADF->>AAD: 2. POST /oauth2/v2.0/token (client_credentials)<br/>scope=https://graph.microsoft.com/.default
    AAD-->>ADF: Return Access Token
    ADF->>GRAPH: 3. Resolve Drive: GET /v1.0/sites/{hostname}:{siteUrl}:/drive<br/>(Bearer Token)
    GRAPH-->>ADF: Return driveId
    ADF->>GRAPH: 4. List Children: GET /v1.0/drives/{driveId}/root/children<br/>(Bearer Token)
    GRAPH-->>ADF: Return files and folders
    ADF->>GRAPH: 5. Download File: GET /v1.0/drives/{driveId}/items/{itemId}/content<br/>(Bearer Token)
    GRAPH-->>ADF: File Content (binary stream)
    ADF->>ADLS: 6. Write File (Managed Identity)
    ADLS-->>ADF: Success
    ADF->>ADF: 7. Log result to SQL (Managed Identity)
```

### Token Acquisition Details

The token is acquired via a Web Activity in ADF that POSTs to the SharePoint tenant's AAD v2.0 token endpoint:

```
POST https://login.microsoftonline.com/{sharepoint-tenant-id}/oauth2/v2.0/token

grant_type=client_credentials
&client_id={app-client-id}
&client_secret={secret-from-key-vault}
&scope=https://graph.microsoft.com/.default
```

### Authentication Methods

| Resource | Authentication Method | Identity | Tenant |
|----------|----------------------|----------|--------|
| Microsoft Graph API (SharePoint) | OAuth 2.0 client_credentials (Service Principal) | Azure AD App Registration | SharePoint (Hydro One) Tenant |
| ADLS Gen2 | Managed Identity | ADF System-Assigned MI | MCAPS Tenant |
| Azure SQL | Managed Identity | ADF System-Assigned MI | MCAPS Tenant |
| Key Vault | Managed Identity | ADF System-Assigned MI | MCAPS Tenant |

## Data Flow

### Initial Migration Flow

```mermaid
flowchart LR
    A[Control Table] --> B[Acquire Token<br/>KV Secret → AAD]
    B --> C{ForEach Library}
    C --> D[Resolve Drive ID<br/>GET /v1.0/sites/host:path:/drive]
    D --> E[Delta Query<br/>GET /v1.0/drives/driveId/root/delta]
    E --> F{Until: All Pages}
    F --> G[Refresh Token<br/>AAD caches ~500ms]
    G --> H[Get Delta Page]
    H --> I[Filter: Files only<br/>exclude deleted]
    I --> J[ExecutePipeline:<br/>PL_Copy_File_Batch]
    J --> K[Set_HasMorePages<br/>via @if expression]
    K --> L{@odata.nextLink?}
    L -->|Yes| M[Wait ThrottleDelay]
    M --> F
    L -->|No| N[Store @odata.deltaLink]
    N --> O{More Libraries?}
    O -->|Yes| C
    O -->|No| P[Update Control Table<br/>Complete]

    subgraph "PL_Copy_File_Batch"
        J --> J1{ForEach File}
        J1 --> J2[Copy via Graph /content]
        J2 --> J3[Write to ADLS Gen2]
        J3 --> J4[Log_Success / Log_Failure]
    end
```

### Detailed Pipeline Data Flow

1. **Token Acquisition**: Web Activity retrieves client secret from Key Vault (via MSI), then POSTs to AAD token endpoint (`https://login.microsoftonline.com/{sharepoint-tenant-id}/oauth2/v2.0/token`) with `scope=https://graph.microsoft.com/.default`
2. **Drive Resolution**: Web Activity calls `GET /v1.0/sites/{hostname}:{siteRelativeUrl}:/drive` to resolve the SharePoint site's default document library to a Graph drive ID
3. **Delta Query**: Web Activity calls `GET /v1.0/drives/{driveId}/root/delta?$top=200` to enumerate ALL files at ALL depths in a flat list
4. **Pagination (Until Loop)**: Until loop follows `@odata.nextLink` to fetch all pages, using only flat activities (see Until Loop Activity Flow below). File copying is delegated to `PL_Copy_File_Batch` via ExecutePipeline
5. **Filter Files**: Filter activity excludes folders and deleted items, keeping only file items
6. **Copy Files via PL_Copy_File_Batch**: ExecutePipeline calls `PL_Copy_File_Batch`, which contains the ForEach loop using `DS_Graph_Content_Download` dataset to GET `/v1.0/drives/{driveId}/items/{itemId}/content` with Bearer token authentication, plus audit logging (Log_Success, Log_Failure)
7. **Folder Path Reconstruction**: Each delta item's `parentReference.path` is parsed to reconstruct the ADLS folder structure
8. **Token Refresh**: Token is refreshed **every iteration** of the Until loop via WebActivity. AAD caches tokens server-side, so redundant refreshes add only ~500ms overhead per iteration. This approach replaces the previous IfCondition-based conditional refresh, which is not allowed inside Until
9. **Pagination Control**: Instead of IfCondition with true/false branches, pagination uses conditional `@if()` expressions in SetVariable to determine the next page URL or signal completion
10. **DeltaLink Storage**: The final `@odata.deltaLink` is stored in SQL for use by incremental sync

### Until Loop Activity Flow

All 3 paginated pipelines (`PL_Migrate_Single_Library`, `PL_Incremental_Sync`, `PL_Process_Subfolder`) use the same restructured Until loop pattern with only flat activities (no nested containers):

```
Refresh_ClientSecret → Refresh_AccessToken → Set_RefreshedToken → Get_DeltaPage → Filter_PageFiles → Execute_CopyFileBatch → Set_HasMorePages → Set_CurrentPageUrl_Next → Set_DeltaLink → Wait_ThrottleDelay
```

| Activity | Type | Purpose |
|----------|------|---------|
| `Refresh_ClientSecret` | WebActivity | Retrieve latest client secret from Key Vault |
| `Refresh_AccessToken` | WebActivity | POST to AAD token endpoint for fresh token (AAD caches server-side, ~500ms) |
| `Set_RefreshedToken` | SetVariable | Store refreshed token for use in subsequent activities |
| `Get_DeltaPage` | WebActivity | Fetch current page of delta/children results from Graph API |
| `Filter_PageFiles` | Filter | Exclude folders and deleted items, keep only files |
| `Execute_CopyFileBatch` | ExecutePipeline | Call `PL_Copy_File_Batch` with filtered file items |
| `Set_HasMorePages` | SetVariable | Use `@if()` expression to check for `@odata.nextLink` |
| `Set_CurrentPageUrl_Next` | SetVariable | Use `@if()` expression to set next page URL or empty string |
| `Set_DeltaLink` | SetVariable | Use `@if()` expression to capture `@odata.deltaLink` if present |
| `Wait_ThrottleDelay` | Wait | Configurable delay between pages (default 2 seconds) |

### ADF Nesting Restrictions

The following ADF nesting restrictions were discovered during development and drove the architectural decision to create `PL_Copy_File_Batch`:

| Restriction | Description |
|-------------|-------------|
| **No ForEach inside Until** | ADF's Until activity cannot contain ForEach, IfCondition, or Switch activities. Only ExecutePipeline is allowed as a container child inside Until |
| **No ForEach inside IfCondition** | ForEach cannot be nested inside an IfCondition activity |
| **No self-referencing variables** | A SetVariable activity's expression cannot reference the same variable being set (no `@variables('x')` in an expression that sets `x`) |
| **No self-referencing pipelines** | ADF rejects ExecutePipeline calls that reference the same pipeline ("circular reference not allowed") |

These restrictions require that any complex logic inside an Until loop be extracted into a separate child pipeline called via ExecutePipeline.

### Incremental Sync Flow

```mermaid
flowchart LR
    A[Read Watermark<br/>+ deltaLink] --> B[Acquire Token<br/>KV Secret → AAD]
    B --> C{Until: All Pages}
    C --> D[Refresh Token<br/>AAD caches ~500ms]
    D --> E[Query Delta Page<br/>via stored deltaLink]
    E --> F[Filter: Files only]
    F --> G[ExecutePipeline:<br/>PL_Copy_File_Batch]
    G --> H[Set_HasMorePages<br/>via @if expression]
    H --> I{@odata.nextLink?}
    I -->|Yes| J[Wait ThrottleDelay]
    J --> C
    I -->|No| K[Store new deltaLink<br/>to SQL]
    K --> L[Complete]
```

## Network Considerations

### Connectivity
- All traffic uses HTTPS (TLS 1.2+)
- No VPN or ExpressRoute required (public endpoints)
- ADF uses Azure Integration Runtime (Auto-resolve)
- Cross-tenant traffic flows via Microsoft Graph API public endpoints

### Conditional Access
If SharePoint is behind Conditional Access policies:
1. Exclude the Service Principal from CA policies, OR
2. Register the Service Principal as an approved app
3. Ensure IP ranges for Azure Data Factory are allowed
4. Verify cross-tenant access policies permit the Service Principal from the MCAPS tenant

### Bandwidth Estimation
| Metric | Value |
|--------|-------|
| Total Data | ~25 TB |
| Available Bandwidth | ~1 Gbps (estimated) |
| Theoretical Transfer Time | ~55 hours (unthrottled) |
| Realistic Transfer Time | 7-14 days (with throttling) |

## Throttling Mitigation Strategy

### Microsoft Graph API Limits

| Limit Type | Value | Mitigation |
|------------|-------|------------|
| Requests per 10-second window | Varies by endpoint | Parallelism control |
| HTTP 429 responses | Variable with Retry-After header | Wait activity + exponential backoff |
| File size limit | 250 GB | N/A (verify largest files) |
| Per-app throttling | Service-specific | Distribute load across time windows |

### Mitigation Approaches

1. **Parallelism Control**: Limit concurrent library migrations (default: 4)
2. **File-level Parallelism**: 10 concurrent files per library
3. **Time-of-Day Scheduling**: Run during off-peak hours (8 PM - 6 AM EST)
4. **Exponential Backoff**: Wait 30s, 60s, 120s on retry
5. **429 Detection**: Dedicated Wait activity when throttled; honor `Retry-After` header from Graph API
6. **Microsoft Engagement**: Request throttling limit increase from account team

### ADF Configuration

| Setting | Recommended Value |
|---------|-------------------|
| DIU (Data Integration Units) | 4-8 |
| Parallel Copies | 4 |
| Degree of Copy Parallelism | 10 |
| Batch Size | 10-20 libraries |

## Error Handling Strategy

### Error Categories

| Error Code | Meaning | Handling |
|------------|---------|----------|
| 401 | Unauthorized | Check token expiry; pipeline refreshes token every Until loop iteration |
| 403 | Forbidden | Check Graph API permissions, cross-tenant consent |
| 404 | Not Found | Log and skip, file/drive may have been deleted |
| 429 | Throttled | Wait per Retry-After header, retry with backoff |
| 503 | Service Unavailable | Retry after delay |
| Timeout | Network/large file | Increase timeout, retry |
| File Locked | Checked out file | Log and retry later |

### Retry Logic
- **Max Retries**: 5 per Graph API call, 3 per library
- **Inter-page Delay**: Configurable (default 2 seconds) between pagination pages
- **Token Refresh**: Refreshed every Until loop iteration (AAD caches tokens server-side; ~500ms overhead). This replaces the previous IfCondition-based conditional refresh, which ADF does not allow inside Until
- **Retry Interval**: Exponential backoff (60s between retries)
- **Circuit Breaker**: Pause batch if >50% failures

## Security Considerations

### Encryption

| Layer | Method |
|-------|--------|
| In Transit | TLS 1.2+ |
| At Rest (SharePoint) | Microsoft-managed encryption |
| At Rest (ADLS) | Microsoft-managed keys (option for CMK) |
| At Rest (SQL) | TDE enabled |

### Access Control

| Resource | Access Control |
|----------|----------------|
| Microsoft Graph API | Service Principal with `Sites.Read.All`, `Files.Read.All` (Application permissions on SharePoint tenant) |
| ADLS Gen2 | Managed Identity with Storage Blob Data Contributor |
| Key Vault | Managed Identity with Key Vault Secrets User |
| SQL Database | Managed Identity with db_datareader, db_datawriter |

### Cross-Tenant Security
- Service Principal is registered in the **SharePoint (Hydro One) tenant**
- Client secret is stored in **Key Vault on the MCAPS tenant**, retrieved by ADF via Managed Identity
- Token is scoped to `https://graph.microsoft.com/.default` and acquired from the SharePoint tenant's AAD endpoint
- No direct SharePoint REST API access; all operations go through Microsoft Graph API

### Compliance
- Data residency: Canada Central region
- No PII/PHI handling required (standard documents)
- Audit logging enabled for compliance tracking

### Network Security
- Storage account: Firewall enabled, Azure services allowed
- SQL Server: Firewall enabled, Azure services allowed
- Key Vault: RBAC authorization enabled

## Production Configuration

| Setting | POC | Production | Verified |
|---------|-----|------------|----------|
| File enumeration | `/root/children` (root + 1 level) | **`/root/delta`** (all depths) | Yes (2026-02-18) |
| Page size ($top) | 999 | **200** | Yes |
| Graph API retries | 3 | **5** | Yes |
| Copy timeout | 30 min | **1 hour** | Yes |
| Token refresh | Never | **Every Until iteration** (AAD caches; ~500ms) | Yes (0 x 401 errors) |
| Inter-page delay | None | **2 seconds** | Yes |
| Subfolder depth | Root + 1 | **Unlimited** (delta) | Yes (Monthly Reports subfolder) |
| ForEach_LibrarySync (incremental) | Parallel (4) | **Sequential** | Yes |
| DeltaLink persistence | No | **Yes** (SQL) | Yes |
| Until loop timeout | N/A | **24 hours** | Yes |

> **Status:** All production settings verified in end-to-end test on 2026-02-18. See [Verified End-to-End Test Results](#verified-end-to-end-test-results) below.

### Pipeline Parameters

#### Parent Pipeline Parameters (PL_Migrate_Single_Library, PL_Process_Subfolder, PL_Incremental_Sync)

| Parameter | Type | Default | Purpose |
|-----------|------|---------|---------|
| `PageSize` | int | 200 | `$top` value for Graph API delta/children calls |
| `CopyBatchCount` | int | 10 | ForEach batchCount for parallel file copy (passed to PL_Copy_File_Batch) |
| `ThrottleDelaySeconds` | int | 2 | Wait time between pagination pages |

#### PL_Copy_File_Batch Parameters

| Parameter | Type | Purpose |
|-----------|------|---------|
| `FileItems` | array | Array of file items to copy (from Filter activity output) |
| `DriveId` | string | Graph API drive ID for source SharePoint library |
| `AccessToken` | string | Bearer token for Graph API authentication |
| `ContainerName` | string | ADLS Gen2 destination container name |
| `SiteName` | string | SharePoint site name (used in ADLS path construction) |
| `LibraryName` | string | SharePoint library name (used in ADLS path construction) |
| `FolderPath` | string | Current folder path within the library |
| `SourcePathPrefix` | string | Prefix to strip from source `parentReference.path` |
| `DestPathPrefix` | string | Prefix to prepend for ADLS destination path |
| `MigrationStatus` | string | Status label for audit logging (e.g., "InitialMigration", "IncrementalSync") |
| `ParentRunId` | string | Parent pipeline run ID for audit log correlation |

### Production Testing

The following tests validate the production features:

| # | Feature | Test Method | Pass Criteria |
|---|---------|-------------|---------------|
| 1 | **Pagination** | Run with `PageSize = 3` | `Until_AllPagesProcessed` runs multiple iterations |
| 2 | **Deep folder traversal** | Create folders at depth 3+ in SharePoint | Files at all depths appear in ADLS |
| 3 | **Token refresh** | Verify token refresh in Until loop iteration | `Refresh_AccessToken` succeeds every iteration (~500ms); AAD caches server-side |
| 4 | **DeltaLink persistence** | Complete initial migration | `IncrementalWatermark.DeltaLink` is non-null |
| 5 | **Incremental sync** | Add file → run `PL_Incremental_Sync` | Only new file copied; stored deltaLink reused |
| 6 | **No-change sync** | Run incremental sync with no changes | 0 files processed |
| 7 | **PL_Copy_File_Batch** | Verify child pipeline executes from Until loop | `Execute_CopyFileBatch` activity succeeds; Log_Success entries in MigrationAuditLog |

**SQL verification queries:**

```sql
-- Verify DeltaLink and DriveId stored after migration
SELECT SiteUrl, LibraryName, DriveId,
    CASE WHEN DeltaLink IS NOT NULL THEN 'Stored' ELSE 'Missing' END AS DeltaLinkStatus,
    LastSyncTime
FROM dbo.IncrementalWatermark;

-- Verify files from all folder depths were migrated
SELECT DestinationPath, MigrationStatus
FROM dbo.MigrationAuditLog
WHERE DestinationPath LIKE '%/%/%/%'
ORDER BY DestinationPath;

-- Verify incremental sync only copied changed files
SELECT FileName, MigrationStatus, [Timestamp]
FROM dbo.MigrationAuditLog
WHERE MigrationStatus = 'IncrementalSync'
ORDER BY [Timestamp] DESC;
```

### Verified End-to-End Test Results

The following results were captured from a live end-to-end test run on **2026-02-18**.

#### Test Run Summary

| Property | Value |
|----------|-------|
| **Pipeline chain** | `PL_Master_Migration_Orchestrator` → `PL_Migrate_Single_Library` → `PL_Copy_File_Batch` |
| **Source** | SharePoint Online `/sites/SalesAndMarketing` / `Shared Documents` |
| **Destination** | ADLS Gen2 `sthydroonemigtest` / `sharepoint-migration/SalesAndMarketing/Shared Documents/` |
| **Duration** | ~2 minutes 5 seconds (Started 4:41:28 PM → Ended 4:43:33 PM UTC) |
| **Status** | **Completed** — all activities Succeeded |

#### File Migration Results

| Metric | Value |
|--------|-------|
| Files migrated | **30** |
| Failures | **0** |
| Total size | **7.96 MB** (7,956,856 bytes) |
| File formats | `.docx`, `.pptx`, `.xlsx`, `.jpg`, `.png` |
| Subfolder support | Verified — files in `Monthly Reports/` subfolder correctly placed in ADLS |

#### Sample Files Migrated

| File | Size | Type |
|------|------|------|
| DG-2000 Product Pitch.pptx | 1.95 MB | Presentation |
| DG-1000 Product Overview.pptx | 1.02 MB | Presentation |
| International Marketing Campaigns.docx | 992 KB | Document |
| DG-2000 Product Overview.docx | 956 KB | Document |
| Branding Elements.pptx | 519 KB | Presentation |
| Germany Sales.xlsx | 20 KB | Spreadsheet (subfolder: Monthly Reports) |
| Canada Sales.xlsx | 21 KB | Spreadsheet (subfolder: Monthly Reports) |

#### Key Features Validated

| # | Feature | Result |
|---|---------|--------|
| 1 | **Delta query pagination** (Until loop with `@odata.nextLink`) | Worked correctly |
| 2 | **Child pipeline pattern** (`PL_Copy_File_Batch` via ExecutePipeline) | No container activity errors |
| 3 | **Subfolder depth** (`parentReference.path` → ADLS folder structure) | Monthly Reports subfolder preserved |
| 4 | **Token refresh** (always-refresh per iteration) | No 401 errors |
| 5 | **SQL audit logging** | All 30 files logged with `Success` status |
| 6 | **MigrationControl status** | Updated to `Completed` automatically |

## Monitoring & Alerting

### Monitoring Points

| Component | Monitoring Method |
|-----------|-------------------|
| ADF Pipelines | ADF Monitor, Azure Monitor |
| Migration Progress | SQL queries, PowerShell script |
| Throttling Events | Audit log (429 error codes from Graph API) |
| Storage | Storage analytics, metrics |

### Alert Thresholds

| Metric | Threshold | Action |
|--------|-----------|--------|
| Pipeline Failure | Any | Email notification |
| Throttling Rate | >10% requests | Reduce parallelism |
| Failed Files | >5% of batch | Pause and investigate |
| Storage Capacity | >90% | Expand storage |

## High-Level Deployment Architecture

```mermaid
graph TB
    subgraph "Resource Group: rg-hydroone-migration-{env} (MCAPS Tenant)"
        ADF[Azure Data Factory<br/>adf-hydroone-migration-{env}]
        ADLS[ADLS Gen2<br/>sthydroonemig{env}]
        SQL[(Azure SQL<br/>sql-hydroone-migration-{env})]
        KV[Key Vault<br/>kv-hydroone-mig-{env}]
    end

    subgraph "Azure AD - MCAPS Tenant"
        MI[Managed Identity<br/>ADF System-Assigned]
    end

    subgraph "Azure AD - SharePoint Tenant"
        SP[App Registration<br/>HydroOne-SPO-Migration]
    end

    subgraph "Microsoft Graph API"
        GRAPH[graph.microsoft.com/v1.0]
    end

    ADF --> MI
    MI --> ADLS
    MI --> SQL
    MI --> KV
    KV --> |Client Secret| SP
    SP --> |OAuth2 client_credentials| GRAPH
    GRAPH --> |drives/items/content| SPO[SharePoint Online]
```

## Environment Configuration

| Environment | Resource Group | Region |
|-------------|----------------|--------|
| Dev | rg-hydroone-migration-dev | Canada Central |
| Test | rg-hydroone-migration-test | Canada Central |
| Prod | rg-hydroone-migration-prod | Canada Central |

## Appendix: Resource Naming Convention

| Resource Type | Naming Pattern | Example |
|---------------|----------------|---------|
| Resource Group | rg-{project}-{purpose}-{env} | rg-hydroone-migration-dev |
| Storage Account | st{project}{purpose}{env} | sthydroonemigdev |
| Data Factory | adf-{project}-{purpose}-{env} | adf-hydroone-migration-dev |
| Key Vault | kv-{project}-{purpose}-{env} | kv-hydroone-mig-dev |
| SQL Server | sql-{project}-{purpose}-{env} | sql-hydroone-migration-dev |
